Command line used to find this crash:

./afl-fuzz -m 800 -i /home/hendrag/corpus/llvm_asan/sox_cmin_llvm_asan -o cmin_1 -f cmin_1/fuzzer04/.cur_input.mp3 -S fuzzer04 ./sox --single-threaded @@ -b 16 -t aiff /dev/null channels 1 rate 16k fade 3 norm

If you can't reproduce a bug outside of afl-fuzz, be sure to set the same
memory limit. The limit used for this fuzzing session was 800 MB.

Need a tool to minimize test cases before investigating the crashes or sending
them to a vendor? Check out the afl-tmin that comes with the fuzzer!

Found any cool bugs in open-source tools using afl-fuzz? If yes, please drop
me a mail at <lcamtuf@coredump.cx> once the issues are fixed - I'd love to
add your finds to the gallery at:

  http://lcamtuf.coredump.cx/afl/

Thanks :-)
